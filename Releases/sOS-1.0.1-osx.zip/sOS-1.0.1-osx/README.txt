sOS
===
You have managed to access the top secret secure system of SPACE HQ.
Can you use your wits (and trusty Hack Boy™ hacking tool) to steal
the precious SPACE PLANS without being caught?


A Ludum Dare 36 Jam entry by:
Arne Roomann-Kurrik - https://twitter.com/kurrik
Kalev Roomann-Kurrik - https://twitter.com/kalevrk
Wes Goodman - https://twitter.com/wes_g_tho
